/**
 * Index file for Core Integration module
 * Module ID: M01.09
 */

export * from './CoreIntegration';
